# Sistemadecadastro_em_C
 1-  Um sistema de cadastro de pacientes de covid-19 produzido para o PIM da UNIP
 
 
 2- O sistema nao esta finalizado, porem, ja mostra o desenvolvimento

![image](https://user-images.githubusercontent.com/112484674/200171156-8091158b-2726-4366-a515-b14425b7e15f.png)
![image](https://user-images.githubusercontent.com/112484674/200171192-4a962218-7a4e-4370-919a-f775c107b641.png)
![image](https://user-images.githubusercontent.com/112484674/200171221-77834ecb-5f31-46d6-95e7-1531585b7b47.png)
![image](https://user-images.githubusercontent.com/112484674/200171232-d9941942-d602-41ad-8b53-c45f883eb696.png)

